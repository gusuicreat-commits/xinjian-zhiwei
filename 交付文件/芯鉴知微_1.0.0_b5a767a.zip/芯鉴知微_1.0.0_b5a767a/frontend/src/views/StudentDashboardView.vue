<script setup lang="ts">
import {
  Bell,
  Document,
  HomeFilled,
  List,
  Refresh,
  SwitchButton,
  TrendCharts,
  UserFilled,
  Warning,
} from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'

import DeviceOverview from '@/components/DeviceOverview.vue'
import DiagnosisPanel from '@/components/DiagnosisPanel.vue'
import RealtimeLogList from '@/components/RealtimeLogList.vue'
import SensorTrendChart from '@/components/SensorTrendChart.vue'
import { useStudentDashboardStore } from '@/stores/studentDashboard'
import { useStudentSessionStore } from '@/stores/studentSession'
import type { FeedbackAction } from '@/types/student'

const router = useRouter()
const sessionStore = useStudentSessionStore()
const dashboardStore = useStudentDashboardStore()
const activeNavTarget = ref('overview')
let refreshTimer: number | undefined
let navigationFrame: number | undefined

const hasTestData = computed(() => {
  const data = dashboardStore.dashboard
  return Boolean(
    data?.device.is_test_fixture ||
    data?.logs.some((item) => item.is_test_data) ||
    data?.readings.some((item) => item.is_test_data) ||
    data?.diagnosis?.is_test_data ||
    data?.guidance.some((item) => item.is_test_data) ||
    data?.feedback?.is_test_data,
  )
})

const deviceLabel = computed(
  () =>
    dashboardStore.dashboard?.device.display_name ||
    sessionStore.credentials?.deviceId ||
    '设备会话',
)

const navItems = [
  { label: '实验概览', target: 'overview', icon: HomeFilled },
  { label: '实时日志', target: 'logs', icon: Document },
  { label: '传感数据', target: 'readings', icon: TrendCharts },
  { label: '诊断与反馈', target: 'diagnosis', icon: Warning },
]

async function refresh(): Promise<void> {
  if (!sessionStore.credentials) return
  await dashboardStore.load(sessionStore.credentials)
}

async function submitFeedback(action: FeedbackAction): Promise<void> {
  if (!sessionStore.credentials) return
  try {
    await dashboardStore.submitFeedback(sessionStore.credentials, action)
    ElMessage.success('反馈已记录')
  } catch {
    ElMessage.error('反馈提交失败，请稍后重试')
  }
}

async function generateAIExplanation(): Promise<void> {
  if (!sessionStore.credentials) return
  try {
    await dashboardStore.generateAIExplanation(sessionStore.credentials)
    const result = dashboardStore.dashboard?.ai_explanation
    if (result?.status === 'succeeded') ElMessage.success('AI 解释已生成')
    else ElMessage.info(result?.notice || '当前保持规则诊断模式')
  } catch {
    ElMessage.error('AI 解释请求失败，规则诊断结果不受影响')
  }
}

function navigateTo(target: string): void {
  activeNavTarget.value = target
  const section = document.getElementById(target)
  const scrollTarget = section?.firstElementChild ?? section
  scrollTarget?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

function syncActiveNavigation(): void {
  const maxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight)
  if (maxScroll > 80 && window.scrollY >= maxScroll - 8) {
    activeNavTarget.value = navItems[navItems.length - 1]?.target ?? 'diagnosis'
    return
  }
  const activationLine = window.innerWidth <= 780 ? 150 : 160
  let nextTarget = navItems[0]?.target ?? 'overview'
  for (const item of navItems) {
    const section = document.getElementById(item.target)
    const measuredElement = section?.firstElementChild ?? section
    if (measuredElement && measuredElement.getBoundingClientRect().top <= activationLine) {
      nextTarget = item.target
    }
  }
  activeNavTarget.value = nextTarget
}

function handleWindowScroll(): void {
  if (navigationFrame !== undefined) return
  navigationFrame = window.requestAnimationFrame(() => {
    navigationFrame = undefined
    syncActiveNavigation()
  })
}

async function logout(): Promise<void> {
  sessionStore.logout()
  dashboardStore.clear()
  await router.replace('/login')
}

onMounted(() => {
  void refresh()
  refreshTimer = window.setInterval(() => void refresh(), 15_000)
  window.addEventListener('scroll', handleWindowScroll, { passive: true })
})
onBeforeUnmount(() => {
  window.clearInterval(refreshTimer)
  window.removeEventListener('scroll', handleWindowScroll)
  if (navigationFrame !== undefined) window.cancelAnimationFrame(navigationFrame)
})
</script>

<template>
  <main class="student-app">
    <a class="skip-link" href="#main-student-content">跳到主要内容</a>
    <header class="app-topbar">
      <div class="brand-lockup">
        <img src="/assets/xinjian-brand-mark.png" alt="芯鉴知微" />
        <strong>芯鉴知微</strong>
        <span>学生端</span>
      </div>
      <div class="topbar-context"><List /> 当前实验任务 <span>⌄</span></div>
      <div class="topbar-user">
        <button type="button" aria-label="通知"><Bell /></button>
        <div class="avatar"><UserFilled /></div>
        <div>
          <strong>{{ deviceLabel }}</strong
          ><small>临时设备会话</small>
        </div>
        <button type="button" aria-label="退出登录" @click="logout"><SwitchButton /></button>
      </div>
    </header>

    <section id="main-student-content" class="app-content" tabindex="-1">
      <nav class="student-section-nav" aria-label="学生端页面分区">
        <button
          v-for="item in navItems"
          :key="item.target"
          type="button"
          :class="{ active: activeNavTarget === item.target }"
          :aria-current="activeNavTarget === item.target ? 'location' : undefined"
          @click="navigateTo(item.target)"
        >
          <component :is="item.icon" /><span>{{ item.label }}</span>
        </button>
      </nav>
      <div class="content-toolbar">
        <div>
          <p>学生实验工作台</p>
          <span v-if="dashboardStore.dashboard"
            >最近更新
            {{ new Date(dashboardStore.dashboard.generated_at).toLocaleTimeString('zh-CN') }}</span
          >
        </div>
        <el-button :loading="dashboardStore.state === 'loading'" @click="refresh"
          ><Refresh /> 刷新数据</el-button
        >
      </div>

      <el-skeleton
        v-if="dashboardStore.state === 'loading'"
        :rows="10"
        animated
        class="dashboard-skeleton"
      />
      <el-result
        v-else-if="dashboardStore.state === 'error'"
        icon="error"
        title="数据加载失败"
        :sub-title="dashboardStore.errorMessage"
      >
        <template #extra><el-button type="primary" @click="refresh">重新加载</el-button></template>
      </el-result>
      <div v-else-if="dashboardStore.dashboard" class="dashboard-content">
        <el-alert
          v-if="hasTestData"
          title="当前展示测试或模拟数据，不代表真实设备诊断结果。"
          type="warning"
          :closable="false"
          show-icon
        />
        <div id="overview">
          <DeviceOverview
            :task="dashboardStore.dashboard.task"
            :device="dashboardStore.dashboard.device"
          />
        </div>
        <section class="analysis-grid">
          <RealtimeLogList :logs="dashboardStore.dashboard.logs" />
          <SensorTrendChart :readings="dashboardStore.dashboard.readings" />
          <DiagnosisPanel
            :diagnosis="dashboardStore.dashboard.diagnosis"
            :guidance="dashboardStore.dashboard.guidance"
            :feedback="dashboardStore.dashboard.feedback"
            :intervention="dashboardStore.dashboard.intervention"
            :feedback-loading="dashboardStore.feedbackLoading"
            :ai-status="dashboardStore.dashboard.ai_status"
            :ai-explanation="dashboardStore.dashboard.ai_explanation"
            :ai-loading="dashboardStore.aiLoading"
            @feedback="submitFeedback"
            @request-ai="generateAIExplanation"
          />
        </section>
      </div>
    </section>
  </main>
</template>
