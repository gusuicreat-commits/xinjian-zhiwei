"""Xinjian Zhiwei backend application."""
